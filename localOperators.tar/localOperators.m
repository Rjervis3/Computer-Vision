%% Lab: Local Operators
% Authors:
% Renn Jervis (#3762)
% Kevin Lee (#4088)

%% Introduction
% In this lab we are applying local operators to images and exploring the
% wonders of histogram equalization. We will use maps to create corrected
% images and will use linear tramsformation to adjust brightness, gain, and
% contrast of an image.

%% Pixel Transforms
% We begin by reading in an image, converting the data to double form and
% adjusting the gamma, brightness and contrast. 
img = imread('cameraman.tif');
figure; imshow(img);
title('Original cameraman');
img = im2double(img);

%%
% We adjust the gamma of the image using element-wise operator. Gamma
% adjustment equation from Szeliski(eq 3.7), g(x) = [f(x)^(1/(gamma)).
% Using a gamma value of 2.2 we observe a brighter image with slightly more
% visible details, especially on darker areas. 
imgGam = img.^(1/2.2);
imshow(imgGam);
title('Gamma Adjusted Image');
%%
% We now increase the brightness of the image with bias value via linear
% transformation Equation from Szeliski (eq 3.3), g (x) = af(x) +b. Using a
% bias value of (50/255) we observe a overall lighter image, slightly foggy
% and with no apparent increase in detail. 
imgBright = img + (50/255);
figure; imshow(imgBright);
title('Image of Increased Brightness');

%%
% Finally, we increase contrast of image with gain value 1.75. We
% observe that the image sky appear to be washed out and the white
% background details are more indistict. It has also become very diffult to
% see the coat details or separate the buildings from the sky.
imgCon = img * 1.75;
imshow(imgCon);
title('Contrast increased Image');

%% Computing Histograms
% In this section we explore the histogram of the above image.
img2 = imread('cameraman.tif');
% display histogram with hist (need double values)
% hist(double(img2(:)));
% bin size = 25

% manually arrange bins (size 1) 0 to 255

xhist = hist(double(img2(:)), 0:1:255 );
%%
% We use 'bar' function to display bar graph of the histogram we just
% created with appropriate labels. Brightness values around 20 are
% the most frequent. We expect to see the most detail emerge out of darker
% areas.
figure;
bar( 0:255, xhist);
xlabel('Pixel Value');
ylabel('Frequency');
title('Pixel Value vs Frequency');
 
% Image Mapping
% We have previously seen we can adjust the gain of the image to increase
% the contrast, but we can also see many details of an image by spreading
% out the brightness values more uniformly using a map. 

% create an image of square with hole in it (code snippet from lab)
S = zeros(128,'uint8');  % Black background
S(32:96,32:96) = 2;      % Square
S(48:80,48:80) = 1;      % Hole  
 
%imshow(S);
% Create a 3 element brightness map.
map = uint8([0 128 255]); 
% we now use s to index map. We must convert to a double to avoid matlab
% error.
S2 = map(double(S)+1); 
%imshow(S2);

% Now create another test map and create new image
map2 = uint8([7 56 200]);
S3 = map2(double(S)+1);
%imshow(S3);

%% Histogram Equalization
% In this section we use the cumulative distribution of the image to
% equalize the histogram and create a corrected image with 'smoothed'
% brightness values.

cumulative = cumsum(xhist);
% create the cumulative distribution function from histogram counts.
figure;
plot((0:255), cumulative);
xlabel('Pixel Intensity');
ylabel('Pixel Count');
title('Cumulative Distribution Function');
% Cumulative distribution min: 0, max: 65536
% we create a map to normalize the histogram of the image
cumulativeMap = cumulative / (256 ^ 2) * 255;
cMap8 = uint8(cumulativeMap);
histCorrected = cMap8(img2);
figure;
imshow(histCorrected);
title('Histogram Corrected Image');

figure;
hist(double(histCorrected(:)))
title('Histogram of Corrected Image');


%%
% We observed that the histogram of the corrected image was much
% flatter than the uncorrected image. In the corrected image we observed
% more detail in the darker portions of the image, such as the cameraman's
% coat. The sky in the image appeared less uniform in intensity in the
% corrected image, with noticable lighter portions. Overall image quality 
% perhaps not increased.

%% Conclusion
% In this lab, we manipulated an original image to explore correction
% methods using various transformations and mappings, including linear
% transformations to increase brightness and contrast (with gain and bias)
% and gamma correction. We explored mapping by mapping onto a test image of
% a square with a hole. Finally, we used histogram equalization to bring
% out details in darker regions of the cameraman image. 

%% Acknowlegements 
% The cameraman image is owned by MIT and licensed for use in Matlab demos
% by the Mathworks. 



