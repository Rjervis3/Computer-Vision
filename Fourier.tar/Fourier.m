%% Fourier Transformations
% Authors: Renn Jervis (3762) and Shaun Mataire (4119)



%% Introduction
% In this lab, we will be applying common filters to images in the
% frequency domain to explore the convolution theorem, which states that
% convolution in the spatial domain is equivalent to multiplication in the
% Fourier domain. We begin by examining the properties of a Fourier
% transform by considering the effect of a Fourier transformation on a
% Gaussian Kernel. We will then use this 'transformed' Gaussian for
% smoothing in the frequency domain. Then we will explore the Laplacian of
% the Gaussian, which we may use as a filter kernel to detect edges in the
% image. Finally, we examine a box filter's Fourier transformation to
% visualize the effect a box filter has on the frequencies in an image.



%% The Fourier Transform of a Gaussian
% In this section we generate a Gaussian with a variance of one and compare
% its (normalized) shape to the shape of its Fourier transform in 3
% dimensions.

% create domain for x and y
[xx,yy] = meshgrid( linspace(-20,20,256), linspace(-20,20,256) ); 

% directly calculate a Gaussian with variance of one
gauss=exp(-(xx.^2+yy.^2)/2);
gaussn = gauss/(sum(sum(gauss))); % normalize the matrix
figure;
%subplot(1, 2, 1);
mesh(gaussn);  % plot 3D image
title('Original Gaussian Kernel');
% create and shift the fast fourier transform of the Gaussian for display
gaussfourier = fft2(gaussn);
gaussfouriershift=fftshift(gaussfourier);
%subplot(1, 2, 2);
figure;
mesh (abs(gaussfouriershift)); % plot the magnitude in 3D
title('Shifted Fourier Transform of Gaussian');
%%
% We see that the shapes of the two graphs are identical, but the scales
% differ slightly. We know this is because the Fourier transform of a
% Gaussian simply returns a Gaussian with a different scale.

%% Filtering in Frequency Domain
% In this section we will use multiplication to apply filters to an image
% in the frequency domain. We will first examine the Fourier transforms of
% the Gaussian and an original image and then examine the product these
% two images; in effect we are applying a low-pass filter to the image in
% the frequency domain. We will then transform the image back into the
% spatial domain and examine the effects of the applied Gaussian filter.

%%
% First we examine the original image:
cameraman = im2double(imread('cameraman.tif')); 
figure;
imshow(cameraman);
title('Original Image');
%%
% Now we will inspect the log compressed magnitude of the Fourier
% transformation of the image alongside the log compressed magnitude of the
% Fourier transformed Gaussian.

% Note that we take the fast Fourier
% transform and so must shift the image quadrants for correct display.
fftcam = fft2(cameraman); % take fast Fourier transform
fftcamshift = fftshift(fftcam); % adjust quadrants for viewing

figure;
subplot(2, 1, 1);
imshow(log(abs(fftcamshift)+1), []); % display magnitude of compressed img
title('Shifted and log compressed magnitude of cameraman image');

% Now we display the magnitude of the log compressed Gaussian image:

subplot(2, 1, 2);
imshow(log(abs(gaussfouriershift)+1), []);
title('Shifted and log compressed magnitude of Gaussian kernel');

% take the element-wise product of the unshifted images
product = gaussfourier .* fftcam;
productshift = fftshift(product); % shift for correct display
%% 
% Finally, the element-wise product of these two transformations is as
% follows:
figure; % display magnitude of compressed product image
imshow(log(abs(productshift)+1), []); 
title('Shifted Compressed Magnitude of Product of Gaussian and Cameraman');
%%
% We see that the product attenuates the high frequencies (located farther
% away from the center of the image) and preserves the low frequencies
% (represented near the center of the image) of the cameraman Fourier
% transform.

%% 
% We will now take an inverse Fourier transform of this product image,
% extract its real component, and display the shifted version to be
% compared to the convolution of the original image with the 2D Gaussian of
% part 1 in the spatial--signal--domain.We expect these to be equivalent
% because of the convolution theorem.
inversefft=ifft2(product);
realin = real(inversefft);               % extract real components
realinshift = ifftshift(realin);         % shift quadrants back
figure;
subplot(1, 2, 1);
imshow(realinshift);
title('Inverse Fourier Transformed product image');

% for comparison, create an image using conv2
subplot(1, 2, 2);
imshow(conv2(cameraman, gaussn, 'same'));
title('Image using convolution in standard domain');

%%
% The image is obviously blurry due to the loss of the high-frequency
% details (the intent of a Gaussian low-pass filter) but we can still make
% out the larger structures in the image. We see that the image created in
% the Fourier domain has a few artifacts around the edges of the image,
% there are some misplaced dark pixels at the very top right border, for
% example, but it does not have nearly as many border artifacts as the
% convolution image.


%% Using Other Filters
% Where the Gaussian filter smooths the image, other filters can perform
% different operations. We will now examine one of these alternate filters,
% namely the Laplacian of the Gaussian, look at its effects on an image in
% the Fourier domain, and examine the inversely-transformed image that it
% produces.

LoG = -(1-(xx.^2+yy.^2)/2).*gauss;     % equation for Laplacian of Gaussian
%%
% First we compute the Laplacian of our initial Gaussian and display it in
% both 3D and 2D representations.
figure;
mesh(LoG);
title('3D visualization of Laplcian of Gaussian Filter');
figure;
imshow(LoG, []);
title('2D visualization of Laplcian of Gaussian Filter');

%%
% Based on these visualizations, we predict that the filter will detect
% structures within a specific range of frequencies, excluding both many
% high and some very low frequencies. We expect that this will show us the
% edges in the image because the Laplacian of the Gaussian is effectively a
% second derivative and thus ought to show us where the derivative changes
% rapidly, indicating an edge.

fftLoG = fft2(LoG); % take Fourier Transform
fftLoGshift = ifftshift(fftLoG);
%%
% We now examine the log compressed magnitude of the Fourier transform of
% the Laplacian of Gaussian.
figure;
imshow(log(abs(fftLoGshift)+1), []);
title('Fourier Transform of Laplacian of Gaussian Filter');
%%
% Based on this visualization of the image, we would expect the filter to
% filter out most high frequencies (as the Gaussian did) but also to filter
% out some very low frequencies (only the frequencies in the donut are
% preserved).

% take component-wise product of cameraman and LoG filter
product2 = fftcam .* fftLoG;
inverse2 = ifft2(product2);  % take inverse Fourier transform
inverse2real = real(inverse2); % extract real component
inverse2realshift = ifftshift(inverse2real);
%%
% We now take the product of the transformed cameraman and the transformed
% Gaussian, take the inverse transformation, and extract the real component
% for display. We display the product image alongside an image created by
% convolving the original image and the Laplacian of Gaussian filter for
% comparison.
figure;
subplot(2, 1, 1);
imshow(inverse2realshift, []);
title('Inverse Fourier Transform of Laplacian and Cameraman product');
subplot(2, 1, 2);
imshow(conv2(cameraman, LoG, 'same'), []);
title('Convolution of Cameraman and LoG in spatial domain');
%%
% We see that the responses are strongest are where there are edges in the
% image. Responses are positive (white) on one side of the edge and
% negative (black) on the other side of the edge. The gray portions of the 
% image are where there was no change in the derivative of the original 
% image.

%% Experimenting with a Box Filter
% In this section we will create a box filter and visualize its Fourier
% transform.
box = zeros(256, 256);
box2 = box;

box2(1:10,1:10) = 1;  % create 10 by 10 filter of first 10 rows and cols
box2 = box2/(sum(sum(box2))); %normalize

box2fft = fft2(box2);    % take Fourier transform
box2fftshift = fftshift(box2fft);
%%
% Display a shifted and log compressed visualization of the Fourier
% transform of a box filter used for smoothing.
figure;
imshow(log(abs(box2fftshift)+1), []);% display mag of log compressed filter
colormap(jet); % apply a colormap for visualization
title('Colored representation of Fourier transformed box filter');
%% 
% The result is not isotropic, because we preserve waves in the
% horizontal and vertical directions, but lose diagonal waves. This filter
% eliminates many but not all high frequencies and retains the low
% frequencies.

%%
% Before downsampling, we generally want to smooth with a low-pass filter
% such as a Gaussian. If we were to smooth with a box filter such as this
% one we would not be eliminating all of the high frequencies in the 
% image, and this could result in aliasing.

%% Conclusion
% In this lab we examined how we can use multiplication in the Fourier
% domain to achieve equivalent results to convolution in the spatial
% domain. We also examined the transforms of different filters, including
% the Gaussian, the Laplacian of the Gaussian, and a simple box filter to
% see how various Fourier-transformed filters could alter the requencies in
% an image. We found that applying the Gaussian in the Fourier domain as a
% low-pass filter resulted in less artifacts than its corresponding
% convolution, although both approaches blur the image to produce very
% similar results. We also saw that the Laplacian of the Gaussian applied
% in the Fourier domain results in an image that displays where the
% original image has notably strong edges, because the Laplacian of a
% Gaussian is a second derivative. Finally, we examined a
% Fourier-transformed box filter to conclude that it would be a poor choice
% for a filter applied before downsampling, because a failure to
% eliminate high frequencies could result in aliasing.


%% Acknowledgements
% The Cameraman image is a stock image from the matlab library.
